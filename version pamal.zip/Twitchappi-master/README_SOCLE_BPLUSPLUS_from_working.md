Socle B+ / B++ appliqué sur la dernière version stable.
- Ajout /api/content (live/vod)
- Front ORYON TV consomme /api/content pour row VOD FR 20-200 et VOD résultats de recherche.
- Click souris fiabilisé (delegation capture).
- Aucun changement sur /firebase_status (hub).
